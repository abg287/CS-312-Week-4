//jshint esversion:6

// Initialization

  // Require modules
  const express = require( "express" );
  const bodyParser = require( "body-parser" );
  const mongoose = require( "mongoose" );
  const _ = require( "lodash" );

  // Create app
  const app = express();

  // Get port
  let port = process.env.PORT;
  if ( port == null || port == "" ) {
    port = 3000;
  }

  // Get URL and database
  const url = "mongodb+srv://admin:pass@atlascluster.wzdy0ju.mongodb.net/";
  const database = "todolistDB";

  // Initialize modules
  app.use( bodyParser.urlencoded( { extended: true } ) );
  app.set( "view engine", "ejs" );
  app.use( express.static( "public" ) );
  mongoose.connect( url + database );

  // Schemas
  const itemsSchema = { name: String };

  const listsSchema = {
    name: String,
    items: [ itemsSchema ]
  };

  // Models
  const Item = mongoose.model( "Item", itemsSchema );
  const List = mongoose.model( "List", listsSchema );

  // Items
  const item1 = new Item( { name: "Welcome to your Todo List!" } );
  const item2 = new Item( { name: "Hit the + button to add a new item" } );
  const item3 = new Item( { name: "<-- Hit this to delete an item." } );
  const defaultItems = [ item1, item2, item3 ];


////////////////////////////////////////////////////////////////////////////////


// Get methods

  // Get landing page
  app.get( "/", ( req, res ) => {

    // Find any list
    Item.find()

      // Try getting list
      .then( () => {

        // Find "Today"/landing page list
        List.findOne( { name: "Today" } )

          // Try finding list
          .then( ( foundList ) => {

            // If there is no "Today"/landing page list
            if ( !foundList ) {

              // Create new "Today"/landing page list
              const list = new List( {
                name: "Today",
                items: defaultItems
              });

              // Save list to database, log update, and go to landing page
              list.save();
              console.log( "Created Today List\n" );
              res.redirect( "/" );
            }

            // Otherwise (There was a "Today"/landing page list)
            else {

              // Show current "Today"/landing page list (vie ejs)
              res.render( "list", {
                listTitle: foundList.name,
                newListItems: foundList.items
              });

              // Log action
              console.log( "Going to Today List\n");
            }
          })

          // Catch error
          .catch( ( err ) => {
            console.log( err );
          });
      })

      // Catch error
      .catch( ( err ) => {
        console.log( err );
      });
  });



  // Get custom page
  app.get( "/:customListName", ( req, res ) => {

    // Capitalize first letter of custom name and the rest lower case
    const customListName = _.capitalize( req.params.customListName );

    // If user wants "Today" list, then get landing page
    if ( customListName === "Today" ) {
      res.redirect( "/" );
    }

    // Otherwise (It's a custom name)
    else {

      // Find custom list
      List.findOne( { name: customListName } )

        // Try getting custom list page
        .then( ( foundList ) => {

          // If custom list doesn't exist
          if ( !foundList ) {

            // Create custom list
            const list = new List({
              name: customListName,
              items: defaultItems
            });

            // Save list to database, log update, and go to respective page
            list.save();
            console.log( "Created " + customListName + " List\n" );
            res.redirect( "/" + customListName );
          }

          // Otherwise (custom list exists)
          else {

            // show current custom page list (via ejs)
            res.render( "list", {
              listTitle: foundList.name,
              newListItems: foundList.items
            });

            // Log action
            console.log( "Going to " + customListName + " List");
            console.log( "---------------------------------------------------");
          }
        })

        // Catch error
        .catch( ( err ) => {
          console.log( err );
        });
    }
  });


////////////////////////////////////////////////////////////////////////////////


// Post Methods

  // Post new item to respective list
  app.post( "/", ( req, res ) => {

    // Obtain list and item name
    const itemName = req.body.newItem;
    const listName = req.body.list;

    // Create new item
    const item = new Item( { name: itemName } );

    // Find current list name
    List.findOne( { name: listName } )

      // Try posting item
      .then( ( foundList ) => {

        // Find item name
        Item.findOne( { name: itemName } )

          // Try finding item
          .then( ( foundItem ) => {

            // If item is not in database, store in database
            if ( !foundItem ) {
              item.save();

              // Log update
              console.log( "Created task of \"" + itemName + "\"\n" );
            }
          })

          // Catch error
          .catch( ( err ) => {
            console.log( err );
          });

        // Push item to respective list
        foundList.items.push( item );

        // Log update
        console.log( "Added task of \"" + itemName + "\"\n" );

        // Save list to database, log update, and go to respective page
        foundList.save();
        console.log( "Updated " + listName + " List\n" );
        res.redirect( "/" + listName );
      })

      // Catch error
      .catch( ( err ) => {
        console.log( err );
      });
  });



  // Post respective list without the deleted item
  app.post( "/delete", ( req, res) => {

    // Obtain ID and list name
    const checkedItemId = req.body.checkbox;
    const listName = req.body.listName;

    // Find list and delete item
    List.findOneAndUpdate(
      { name: listName },
      { $pull: { items: { _id: checkedItemId } } } )

      // Try posting new list page
      .then( ( foundList ) => {

        // Log update
        console.log( "Completed task on " + listName + "\n");

        // Go to respective list page
        res.redirect( "/" + listName );
      })

      // Catch error
      .catch( ( err ) => {
        console.log( err );
      });
  });


////////////////////////////////////////////////////////////////////////////////


// OTHER

  // Console listening to a port
  app.listen( port, () => {
    console.log( "Server has started successfully\n" );
  });
